# pragma once
# include "Predicate.h"
# include "Parameter.h"
# include "Rule.h"
# include "Datalog_Program.h"